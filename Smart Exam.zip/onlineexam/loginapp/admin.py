from django.contrib import admin
from loginapp.models import Question

# Register your models here.
admin.site.register(Question)
